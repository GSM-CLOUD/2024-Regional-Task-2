package org.worldskills.cloud.skillsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillsBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
